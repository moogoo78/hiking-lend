--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2
-- Dumped by pg_dump version 15.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: entity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.entity (
    id integer NOT NULL,
    name character varying(500),
    store_id integer,
    status character varying(10)
);


--
-- Name: entity_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.entity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: entity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.entity_id_seq OWNED BY public.entity.id;


--
-- Name: lend_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lend_log (
    id integer NOT NULL,
    memo character varying(500),
    entity_id integer
);


--
-- Name: lend_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lend_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lend_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lend_log_id_seq OWNED BY public.lend_log.id;


--
-- Name: lending; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lending (
    id integer NOT NULL,
    person character varying(500),
    phone character varying(500),
    date_start date,
    date_end date,
    store_id integer,
    remarks text
);


--
-- Name: lending_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lending_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lending_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lending_id_seq OWNED BY public.lending.id;


--
-- Name: model_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_history (
    id integer NOT NULL,
    tablename character varying(500),
    item_id character varying(500),
    action character varying(500),
    changes jsonb,
    created timestamp without time zone,
    remarks character varying(500)
);


--
-- Name: model_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.model_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: model_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.model_history_id_seq OWNED BY public.model_history.id;


--
-- Name: store; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.store (
    id integer NOT NULL,
    title character varying(500),
    address text,
    latitude_decimal numeric(9,6),
    longitude_decimal numeric(10,7)
);


--
-- Name: store_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.store_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: store_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.store_id_seq OWNED BY public.store.id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."user" (
    created timestamp without time zone,
    updated timestamp without time zone,
    id integer NOT NULL,
    username character varying(500),
    passwd character varying(500),
    phone character varying(500),
    email character varying(500),
    status character varying(1),
    admin_store_id integer
);


--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: entity id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entity ALTER COLUMN id SET DEFAULT nextval('public.entity_id_seq'::regclass);


--
-- Name: lend_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lend_log ALTER COLUMN id SET DEFAULT nextval('public.lend_log_id_seq'::regclass);


--
-- Name: lending id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lending ALTER COLUMN id SET DEFAULT nextval('public.lending_id_seq'::regclass);


--
-- Name: model_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_history ALTER COLUMN id SET DEFAULT nextval('public.model_history_id_seq'::regclass);


--
-- Name: store id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store ALTER COLUMN id SET DEFAULT nextval('public.store_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
11202f046c60
\.


--
-- Data for Name: entity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.entity (id, name, store_id, status) FROM stdin;
2	inreach2	1	F
3	inreach3	2	F
4	inreach4	3	F
1	inreach1	1	F
5	inreach5	4	F
6	inreach6	3	F
7	inreach7	2	F
8	inreach8	4	F
\.


--
-- Data for Name: lend_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lend_log (id, memo, entity_id) FROM stdin;
\.


--
-- Data for Name: lending; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lending (id, person, phone, date_start, date_end, store_id, remarks) FROM stdin;
\.


--
-- Data for Name: model_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_history (id, tablename, item_id, action, changes, created, remarks) FROM stdin;
3	store	2	update	{"latitude_decimal": "None=>234", "longitude_decimal": "None=>234"}	2023-03-02 05:57:49.896965	\N
6	store	2	update	{"latitude_decimal": "None=>22.60", "longitude_decimal": "None=>120.45"}	2023-03-02 06:21:02.356722	\N
7	store	2	update	{"latitude_decimal": "22.600000=>22.607158", "longitude_decimal": "120.450000=>120.450000"}	2023-03-02 06:21:16.231091	\N
8	store	2	update	{"latitude_decimal": "22.607158=>22.607158", "longitude_decimal": "120.450000=>120.312356"}	2023-03-02 06:21:27.123211	\N
9	store	1	update	{"latitude_decimal": "None=>25.0608162", "longitude_decimal": "None=>121.5722508"}	2023-03-02 06:22:12.541766	\N
10	store	3	update	{"latitude_decimal": "None=>25.0120949", "longitude_decimal": "None=>121.4504452"}	2023-03-02 06:22:49.323339	\N
11	store	4	update	{"latitude_decimal": "None=>25.0509776", "longitude_decimal": "None=>121.5675494"}	2023-03-02 06:23:23.119557	\N
12	store	4	update	{"latitude_decimal": "25.050978=>25.0509776", "longitude_decimal": "121.567549=>121.567549"}	2023-03-02 06:30:12.10244	\N
13	store	3	update	{"latitude_decimal": "25.012095=>25.012095", "longitude_decimal": "121.450445=>121.4527305"}	2023-03-02 06:44:55.06952	\N
14	store	3	update	{"latitude_decimal": "None=>25.012095", "longitude_decimal": "None=>121.4527305"}	2023-03-02 06:51:12.026474	\N
15	store	3	update	{"latitude_decimal": "None=>25.012095", "longitude_decimal": "None=>121.4527305"}	2023-03-02 06:53:39.606488	\N
16	store	3	update	{"latitude_decimal": "25.012095=>25.012095", "longitude_decimal": "121.4527305=>121.4545029"}	2023-03-02 06:57:10.726767	\N
17	store	3	update	{"latitude_decimal": "25.012095=>25.0120375", "longitude_decimal": "121.4545029=>121.454752"}	2023-03-02 06:58:12.456774	\N
18	store	3	update	{"latitude_decimal": "25.012038=>25.0120916", "longitude_decimal": "121.4547520=>121.4547507"}	2023-03-02 06:59:45.636093	\N
19	store	3	update	{"latitude_decimal": "25.012092=>25.012111702871948", "longitude_decimal": "121.4547507=>121.45494979618891"}	2023-03-02 07:00:50.063866	\N
20	store	1	update	{"latitude_decimal": "None=>25.060675573895765", "longitude_decimal": "None=>121.57451534269059"}	2023-03-02 07:12:51.865561	\N
21	store	2	update	{"latitude_decimal": "None=>22.61277089270153", "longitude_decimal": "None=>120.31451547143662"}	2023-03-02 07:14:20.133523	\N
22	store	4	update	{"latitude_decimal": "None=>25.05105210587599", "longitude_decimal": "None=>121.56958472727639"}	2023-03-02 07:15:46.239133	\N
23	store	4	update	{"address": "None=>台北市松山區南京東路五段356號15樓", "latitude_decimal": "25.051052=>25.051052", "longitude_decimal": "121.5695847=>121.5695847"}	2023-03-02 07:16:39.210734	\N
24	store	3	update	{"address": "None=>新北市板橋區中正路1巷16弄山旅戶外登山用品工作室1樓", "latitude_decimal": "25.012112=>25.012112", "longitude_decimal": "121.4549498=>121.4549498"}	2023-03-02 07:16:53.229011	\N
25	store	2	update	{"address": "None=>高雄市前鎮區民權二路100mountain 百岳", "latitude_decimal": "22.612771=>22.612771", "longitude_decimal": "120.3145155=>120.3145155"}	2023-03-02 07:17:07.531641	\N
26	store	1	update	{"address": "None=>台北市內湖區新湖二路8號", "latitude_decimal": "25.060676=>25.060676", "longitude_decimal": "121.5745153=>121.5745153"}	2023-03-02 07:17:23.735515	\N
27	entity	1	update	{"store_id": "1=>1"}	2023-03-02 09:21:41.082917	\N
28	entity	5	create	{"name": "None=>inreach5", "status": "None=>F", "store_id": "None=>4"}	2023-03-02 09:22:03.60322	\N
29	entity	6	create	{"name": "None=>inreach6", "status": "None=>F", "store_id": "None=>3"}	2023-03-02 09:22:13.647832	\N
30	entity	7	create	{"name": "None=>inreach7", "status": "None=>F", "store_id": "None=>2"}	2023-03-02 09:22:27.032906	\N
31	entity	8	create	{"name": "None=>inreach8", "status": "None=>F", "store_id": "None=>4"}	2023-03-02 09:22:41.644181	\N
\.


--
-- Data for Name: store; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.store (id, title, address, latitude_decimal, longitude_decimal) FROM stdin;
4	kawas	台北市松山區南京東路五段356號15樓	25.051052	121.5695847
3	山旅戶外	新北市板橋區中正路1巷16弄山旅戶外登山用品工作室1樓	25.012112	121.4549498
2	高雄百岳-高雄總店	高雄市前鎮區民權二路100mountain 百岳	22.612771	120.3145155
1	高雄百岳-台北店	台北市內湖區新湖二路8號	25.060676	121.5745153
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."user" (created, updated, id, username, passwd, phone, email, status, admin_store_id) FROM stdin;
2023-03-02 05:53:34.179097	2023-03-02 05:53:34.179108	1	foo	pbkdf2:sha256:260000$ES9Ng26YjuG8pSW6$9bef6552f2521e99ffbb4aca7b8c8cd3b02da98d925621ab10b8097223d6b5fb	\N	\N	P	\N
\.


--
-- Name: entity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.entity_id_seq', 8, true);


--
-- Name: lend_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.lend_log_id_seq', 1, false);


--
-- Name: lending_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.lending_id_seq', 1, false);


--
-- Name: model_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.model_history_id_seq', 31, true);


--
-- Name: store_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.store_id_seq', 4, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_id_seq', 1, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: entity entity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entity
    ADD CONSTRAINT entity_pkey PRIMARY KEY (id);


--
-- Name: lend_log lend_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lend_log
    ADD CONSTRAINT lend_log_pkey PRIMARY KEY (id);


--
-- Name: lending lending_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lending
    ADD CONSTRAINT lending_pkey PRIMARY KEY (id);


--
-- Name: model_history model_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_history
    ADD CONSTRAINT model_history_pkey PRIMARY KEY (id);


--
-- Name: store store_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store
    ADD CONSTRAINT store_pkey PRIMARY KEY (id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: entity entity_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entity
    ADD CONSTRAINT entity_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.store(id) ON DELETE SET NULL;


--
-- Name: lend_log lend_log_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lend_log
    ADD CONSTRAINT lend_log_entity_id_fkey FOREIGN KEY (entity_id) REFERENCES public.entity(id) ON DELETE SET NULL;


--
-- Name: lending lending_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lending
    ADD CONSTRAINT lending_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.store(id) ON DELETE SET NULL;


--
-- Name: user user_admin_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_admin_store_id_fkey FOREIGN KEY (admin_store_id) REFERENCES public.store(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

